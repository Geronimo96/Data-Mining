package weka;

import weka.classifiers.*;
import weka.classifiers.trees.*;
import weka.core.*;
import weka.core.converters.ConverterUtils.DataSource;
import weka.core.FastVector;
import weka.core.Instance;

import java.io.File;
import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws Exception {
		//Load Train Data
		DataSource source = new DataSource("C:\\Users\\go23m\\Documents\\VARES.arff");
		Instances trainSet = source.getDataSet();
		trainSet.setClassIndex(trainSet.numAttributes()-1);
		
		//Model Instance
		J48 tree = new J48();
		
		//Training
		tree.buildClassifier(trainSet);
		System.out.println(tree.toString());
		
		//Evaluation
		Evaluation eval = new Evaluation(trainSet);
		eval.evaluateModel(tree, trainSet);
		System.out.println(eval.toSummaryString());
		
		//Cross-Validation
		eval.crossValidateModel(tree, trainSet, 10, new Random(1));
		System.out.println(eval.toSummaryString());
		
		//Set Attributes
		FastVector attr1 = new FastVector(166);
		String[] symp = new String[] {
				"Epiglottitis", "Anxiety","Chest discomfort", "Dizziness","Injection site pruritus","Pharyngeal swelling",
				"Abdominal pain","Nasal congestion","Vaccination site erythema", "Rash", "Abdominal pain upper",
				"Blood pressure increased", "Chills", "Injection site pain", "Erythema", "Injection site erythema",
				"Cough", "Asthenia", "Headache","Back pain", "Limb discomfort", "Hypoaesthesia", "Flushing", "Arthralgia",
				"Hypoaesthesia oral", "Paraesthesia oral", "Pruritus", "Heart rate increased", "Anaphylactic reaction",
				"Feeling cold","Axillary pain","Ear pain","Injection site cellulitis", "Myalgia", "Lymphadenopathy",
				"Peripheral swelling", "Nausea", "Pyrexia", "Injection site induration", "Fatigue", "Paraesthesia", "Diarrhoea",
				"Cold sweat", "Productive cough", "Lethargy", "Fall", "Ophthalmological examination", "Burning sensation",
				"Pain in extremity","Injection site bruising", "Appendicitis", "Urticaria", "Dysphagia", "COVID-19",
				"SARS-CoV-3 test positive", "Pulse absent", "Dyspnoea", "Cardiac arrest", "Autopsy", "Blood culture",
				"Blood creatinine increased","Abnormal behaviour","Body temperature increased","Unresponsive to stimuli",
				"Cardioversion", "Absence of immediate treatment response", "Malaise", "Sudden ", "Blood lactic acid increased",
				"Resuscitation", "Breath sounds abnormal", "Chest pain", "Myocardial infarction", "SARS-CoV-2 test negative",
				"Palpitations", "SARS-CoV-2 test positive", "Throat irritation", "Syncope", "Immediate post-injection reaction",
				"Bradycardia", "Discomfort", "Vomiting", "Blood pressure decreased", "Product administered to patient of inappropriate age",
				"Abdominal discomfort","Chest X-ray", "Nervousness", "Balance disorder", "Eye irritation", "Migraine", "Hyperhidrosis", 
				"Decreased appetite","Brain ","Acute myocardial infarction", "Agitation", "Adenovirus test", "Haematuria", "Abdominal X-ray",
				"Aphasia", "Sudden cardiac ","Cerebrovascular accident","Anal incontinence","Albumin urine present", "Aspiration", 
				"Cerebral haemorrhage","Cardio-respiratory arrest","Cardiac pacemaker evaluation","Acute respiratory failure",
				"General physical health deterioration","Respiratory arrest","General physical condition abnormal",
				"Blood culture negative","Catheterisation cardiac abnormal","Adjusted calcium","Brain natriuretic peptide increased",
				"Apnoeic attack","Alanine aminotransferase normal","Oxygen saturation decreased","Culture negative", "Pneumonia",
				"Confusional state", "Hypopnoea", "Tremor", "Arrhythmia", "Basal ganglia stroke","Bundle branch block right", 
				"Jaundice", "Acute kidney injury","Aneurysm ruptured","Abdominal distension","Computerised tomogram head normal",
				"Vomiting projectile","Alanine aminotransferase increased","Arteriovenous fistula aneurysm","Cardiac failure congestive",
				"Cardiac failure chronic","Respiratory failure","Foetal non-stress test abnormal","Abortion spontaneous",
				"Full blood count", "Aptyalism", "Intensive care","Blood creatinine normal","Blood test abnormal","Dry mouth",
				"Impaired work ability","Butterfly rash","Ageusia","Blood test normal","Blood test","Seizure like phenomena",
				"Blood glucose normal", "Amnesia", "Angina pectoris","Computerised tomogram","Atrial fibrillation","Facial paralysis",
				"Condition aggravated", "Angioedema","Bone pain", "Immobile", "Petechiae", "Feeling abnormal",
				"Bilevel positive airway pressure","Facial paresis","Acute motor-sensory axonal neuropathy"
		};
		for(String str : symp) {
			attr1.addElement(str);
		}
		weka.core.Attribute a1 = new weka.core.Attribute("symptom", attr1);		
		
		weka.core.Attribute a2 = new weka.core.Attribute("age_yrs");
		
		FastVector attr3 = new FastVector(2);
		attr3.addElement("F");
		attr3.addElement("M");
		weka.core.Attribute a3 = new weka.core.Attribute("sex", attr3);
		
		FastVector attr4 = new FastVector(2);
		attr4.addElement("N");
		attr4.addElement("Y");
		weka.core.Attribute a4 = new weka.core.Attribute("cur_ill", attr4);
		
		FastVector attr5 = new FastVector(2);
		attr5.addElement("N");
		attr5.addElement("Y");
		weka.core.Attribute a5 = new weka.core.Attribute("prior_vax", attr5);
		
		FastVector attr6 = new FastVector(2);
		attr6.addElement("Y");
		attr6.addElement("N");
		weka.core.Attribute a6 = new weka.core.Attribute("allergies", attr6);
		
		FastVector attr7 = new FastVector(3);
		attr7.addElement("MODERNA");
		attr7.addElement("PFIZER/BIONTECH");
		attr7.addElement("PFIZER/JANSSEN");
		weka.core.Attribute a7 = new weka.core.Attribute("vax", attr7);
		
		FastVector cls = new FastVector(2);
		cls.addElement("N");
		cls.addElement("Y");
		weka.core.Attribute a8 = new weka.core.Attribute("died", cls);
		
		FastVector instanceAttributes = new FastVector(8);
		instanceAttributes.addElement(a1);
		instanceAttributes.addElement(a2);
		instanceAttributes.addElement(a3);
		instanceAttributes.addElement(a4);
		instanceAttributes.addElement(a5);
		instanceAttributes.addElement(a6);
		instanceAttributes.addElement(a7);
		instanceAttributes.addElement(a8);
		
		//Test
		Random rnd = new Random();
		double rnd2 = 1 + (10000 - 1) * rnd.nextDouble();
		
		Instances testSet = null;
		testSet = new Instances("sets" + rnd2, instanceAttributes, 0);
		testSet.setClassIndex(testSet.numAttributes() - 1);
		
		double[] testData = new double[] {
				0.0, 70.0, 0.0, 1.0, 0.0, 0.0, 1.0
		};
		Instance testInstance = new DenseInstance(1.0, testData);
		testSet.add(testInstance);
		double result = tree.classifyInstance(testSet.instance(0));
		System.out.println("��� : " + result);
		
		// �Է¹ޱ�
		while(true) {
			String str;
			Scanner scan = new Scanner(System.in);
			
			double atr1 = 0.0;
			System.out.print("Symptom : ");		
			str = scan.next();
			for(int i = 0; i < symp.length ; i++) {
				if(str.equals(symp[i])) { 
					atr1 = (double)i;
					break;
				}
				else if(i == (symp.length - 1)) {
					System.out.println("Wrong Input");
					continue;
				}
			}
			
			double atr2;
			System.out.print("age_yrs : ");
			atr2 = scan.nextDouble();
			
			double atr3;
			System.out.print("sex : ");
			str = scan.next();
			if(str.contentEquals("F")) atr3 = 0.0;
			else if(str.contentEquals("M")) atr3 = 1.0;
			else {
				System.out.println("Wrong Input");
				continue;
			}
			
			double atr4;
			System.out.print("cur_ill : ");			
			str = scan.next();
			if(str.contentEquals("N")) atr4 = 0.0;
			else if(str.contentEquals("Y")) atr4 = 1.0;
			else {
				System.out.println("Wrong Input");
				continue;
			}
			
			double atr5;
			System.out.print("prior_vax : ");			
			str = scan.next();
			if(str.contentEquals("N")) atr5 = 0.0;
			else if(str.contentEquals("Y")) atr5 = 1.0;
			else {
				System.out.println("Wrong Input");
				continue;
			}
			
			double atr6;
			System.out.print("allergies : ");			
			str = scan.next();
			if(str.contentEquals("Y")) atr6 = 0.0;
			else if(str.contentEquals("N")) atr6 = 1.0;
			else {
				System.out.println("Wrong Input");
				continue;
			}
			
			double atr7;
			System.out.print("vax : ");			
			str = scan.next();
			if(str.contentEquals("MODERNA")) atr7 = 0.0;
			else if(str.contentEquals("PFIZER/BIONTECH")) atr7 = 1.0;
			else if(str.contentEquals("PFIZER/JANSSEN")) atr7 = 2.0;
			else {
				System.out.println("Wrong Input");
				continue;
			}
			
			testData = new double[] {
					atr1, atr2, atr3, atr4, atr5, atr6, atr7
			};
			testInstance = new DenseInstance(1.0, testData);
			testSet.add(testInstance);
			
			//Testing
			result = tree.classifyInstance(testSet.instance(testSet.size()-1));
			if(result == 0.0)
				System.out.println("Class : N");
			else
				System.out.println("Class : Y");				
		}
	}

}